package com.iesports.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.iesports.dao.service.impl.TournamentServiceImpl;
import com.iesports.model.Person;
import com.iesports.model.Tournament;

@RestController
@RequestMapping("/Tournament")
public class TournamentController {

	@Autowired
	private TournamentServiceImpl ts;
	
	@GetMapping("/get-tournaments")
	public ResponseEntity<?> login(@RequestParam(required = false) Integer sport_id, @RequestParam(required = false) String date) {
		
		List<Tournament> tournaments = null;
		
		if(!sport_id.equals(null) && !date.equals(null)) {
			tournaments = ts.findTournamentsBySportIdAndDate(sport_id, date);
		}
		
		if(!date.equals(null)) {
			tournaments = ts.findTournamentsBySportId(sport_id);
		}
		
		if(!date.equals(null)) {
			tournaments = ts.findTournamentsByDate(date);
		}
		
		if(tournaments.equals(null)) {
			tournaments = ts.getTournaments();
			
			// Orndena los torneos por de mas reciente a mas antiguo por fecha
		    tournaments =  tournaments.stream()
	                .sorted((t1, t2) -> t2.getDate().compareTo(t1.getDate()))  
	                .collect(Collectors.toList());
		}
		
		return ResponseEntity.ok(tournaments);
	}
	
	@GetMapping("/get-dates")
	public ResponseEntity<?> getDates(){
		return ResponseEntity.ok(ts.findTournamentsDates());
	}
}
