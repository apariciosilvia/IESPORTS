package example.iesports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IesportsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IesportsApplication.class, args);
	}

}
